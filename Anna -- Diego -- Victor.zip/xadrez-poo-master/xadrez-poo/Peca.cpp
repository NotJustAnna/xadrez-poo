#include "Peca.h"

/**
 * Desenha a peça.
 */
void Peca::desenha() {
    /*
    SEM IMPLEMENTAÇÃO.
    */
}

/**
 * Checa a movimentação de uma peça do tabuleiro,
 * retornando verdadeiro se a movimentação é válida.
 */
bool Peca::checaMovimento(int linhaOrigem, int colunaOrigem, int linhaDestino, int colunaDestino) {
    /*
    SEM IMPLEMENTAÇÃO.
    */
    return false;
}