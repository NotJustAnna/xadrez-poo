/**
 * Retorna o sinal do número.
 */
int sgn(int v);